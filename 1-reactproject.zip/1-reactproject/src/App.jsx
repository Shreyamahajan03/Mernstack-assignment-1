import Photos from "./Photos.jsx";

function App() {

  return (
    <>
      <Photos />
    </>
  );

}

export default App;